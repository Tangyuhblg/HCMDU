import random
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import KFold
from sklearn.preprocessing import MinMaxScaler
import warnings
warnings.filterwarnings('ignore')
from Comparison import Evaluation_indexs
import time


if __name__ == '__main__':

    start_time = time.time()

    df = pd.read_csv('../Result/amq-5.0.0-code_vectors.csv')
    print("是否有缺失值:", df.isnull().values.any())

    data_frame = np.array(pd.read_csv('../Result/amq-5.0.0-code_vectors.csv'))
    print('样本个数: ', data_frame.shape[0], '特征个数: ', data_frame.shape[1] - 2)
    data = data_frame[:, 1: -1]
    target = data_frame[:, -1].astype(int)
    print('缺陷率：', np.sum(target == 1) / data.shape[0])

    # 归一化
    scaler = MinMaxScaler()
    data = scaler.fit_transform(data)

    n_split = 5
    kfold = KFold(n_splits=n_split, shuffle=True, random_state=42)

    origin_index = df.index.to_numpy() # 原始行号
    # 预先分配一个数组来存放“整体验证集预测标签”，便于回填到原始表
    # 初始化为 -1 表示训练集或尚未预测
    y_pred_all = np.full(shape=(len(df),), fill_value=-1, dtype=int)
    # 收集所有预测为缺陷=1 的“原始行号”
    predicted_defect_rows = []

    F_measure, TPR, FPR, FNR, G_mean, MCC, AUC = [], [], [], [], [], [], []
    F_measure_smo, FPR_smo, FNR_smo, G_mean_smo, MCC_smo, AUC_smo = [], [], [], [], [], []
    for kf, (train_index, test_index) in enumerate(kfold.split(data)):
        X_train, X_test = data[train_index], data[test_index]
        y_train, y_test = target[train_index], target[test_index]
        # print('多数类数量%d, 少数类数量%d' % (len(X_train[y_train == 0]), len(X_train[y_train == 1])))

        model = RandomForestClassifier(random_state=42)
        model.fit(X_train, y_train)
        pred = model.predict(X_test)

        # 把本折预测映射回“原始数据行号”
        global_test_rows = origin_index[test_index]  # 本折验证集对应的原始行号
        defect_mask = (pred == 1)
        defect_rows_this_fold = global_test_rows[defect_mask]
        predicted_defect_rows.extend(defect_rows_this_fold.tolist())
        # 同时把本折预测标签写入 y_pred_all（对应原始行号）
        y_pred_all[global_test_rows] = pred

        tpr, fpr, fnr, gmean, mcc, auc = Evaluation_indexs.evaluation_indexs(y_test, pred)
        TPR.append(tpr)
        FPR.append(fpr)
        FNR.append(fnr)
        G_mean.append(gmean)
        MCC.append(mcc)
        AUC.append(auc)

    print(G_mean, AUC, FPR, FNR)
    print('希尔伯特 G-mean: %.4f' % np.mean(G_mean))
    print('希尔伯特 MCC: %.4f' % np.mean(MCC))
    print('希尔伯特 AUC: %.4f' % np.mean(AUC))
    print('希尔伯特 FPR: %.4f' % np.mean(FPR))
    print('希尔伯特 FNR: %.4f' % np.mean(FNR))

    # # 直接给出“预测为缺陷=1”的原始行号列表
    # print("预测为缺陷的原始行号总数：", len(predicted_defect_rows))
    # predicted_defect_rows_1based = [i+1 for i in predicted_defect_rows]
    # print("前20个原始行号:", predicted_defect_rows_1based[:20])
    #
    # # 把预测结果回填到原始表并导出映射 CSV
    # df_out = df.copy()
    # df_out['predict_defect'] = y_pred_all  # -1=训练集/未预测，0=预测不缺陷，1=预测缺陷
    # # 只导出验证集中出现过的行（y_pred_all!=-1），并按“预测为1”筛选
    # pred_defect_df = df_out[df_out['predict_defect'] == 1].copy()
    # pred_defect_df.insert(0, 'origin_index', pred_defect_df.index + 1) # 原始数据从0开始
    # pred_defect_df.insert(1, 'predict_index', pred_defect_df.index + 1)
    #
    # # 保存映射文件（包含原始行号 + 原始字段 + 预测标签）
    # out_map_path = '../Result/predicted_defects.csv'
    # pred_defect_df.to_csv(out_map_path, index=False, encoding='utf-8')
    # print(f"预测为缺陷的样本映射已保存到: {out_map_path}")
    #
    # # 保存最终文件
    # java_code = pd.read_csv('../Result/java_clean_code.csv')
    # java_file_content = java_code['content']
    # file_content= java_file_content.iloc[pred_defect_df.index]
    # predict_csv = pred_defect_df.join(file_content)
    # # 保留origin and predict的index and label, source code
    # col = ['file', 'content', 'origin_index', 'predict_index', 'defects', 'predict_defect']
    # output_path = '../Result/predict_defect_code.csv'
    # predict_csv[col].to_csv(output_path, index=False, encoding='utf-8')
    # print(f'最终结果已保存到：{output_path}')


    end_time = time.time()
    print('总时间%ds' % (end_time - start_time))









