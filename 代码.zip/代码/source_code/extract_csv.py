import os
import pandas as pd
import re
import json
import warnings
warnings.simplefilter(action='ignore', category=pd.errors.PerformanceWarning)


def read_java_file_without_comments(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        file_content = file.read()
        file_content = re.sub(r'//.*?\n|/\*.*?\*/', '', file_content, flags=re.DOTALL)
        return file_content


def extract_tokens_from(file_level_path, release, file_level_path_suffix):

    record = [] # 记录代码内容和标签

    path = f'{file_level_path}{release}{file_level_path_suffix}'
    with open(path, 'r', encoding='utf-8', errors='ignore') as file:
        lines = file.readlines()

    src_file_indices = [lines.index(line) for line in lines if r'.java,true,"' in line or r'.java,false,"' in line] # 在 CSV 中定位每个 Java 源文件起始行索引
    src_files = [lines[index].split(',')[0] for index in src_file_indices] # 文件名字
    string_labels = [lines[index].split(',')[1] for index in src_file_indices] # 文件标签
    numeric_labels = [0 if label == 'true' else 1 for label in string_labels] # true->0, false->1
    assert (len(numeric_labels) == len(src_file_indices)) # 检查标签和文件序号一致性

    for i in range(0, int(len(src_file_indices))):
        dfs = [] # 用于拼接 DataFrame

        s_index = src_file_indices[i] # 当前文件在CSV中的起始行
        e_index = src_file_indices[i + 1] if i + 1 < len(src_file_indices) else len(lines) # 当前文件结束行
        code_lines = [line.strip() for line in lines[s_index:e_index]] # 取出该文件所有代码行
        # print(src_file_indices)
        # print(code_lines)
        code_lines[0] = code_lines[0].split(',')[-1][1:] # /*...*/+code 去掉"
        code_lines[-1] = code_lines[-1][:-1] # 去掉"
        if len(code_lines) == 0:
            continue

        # 将源码片段写入临时 Java 文件，便于后续去注释
        f = open("Result/tmp.java", 'w', encoding='utf-8')
        for line in code_lines:
            print(line, end='', file=f) # 使用 end=''，每行会被额外添加一个换行符
        f.close()
        java_contents = [read_java_file_without_comments('Result/tmp.java')]
        if java_contents == ['']:
            continue

        record.append({'file':src_files[i], 'content':java_contents, 'label':numeric_labels[i]})

    return record



# if __name__ == '__main__':
#
#     dataset_string = './Dataset'
#     result_string = './Result'
#
#     file_level_path = f'{dataset_string}/File-level/'
#     line_level_path = f'{dataset_string}/Line-level/'
#     result_path = f'{result_string}'
#
#     file_level_path_suffix = '_ground-truth-files_dataset.csv'
#     line_level_path_suffix = '_defective_lines_dataset.csv'
#
#     releases = [
#         'ambari-2.1.0'
#     ]
#
#     os.makedirs(result_path, exist_ok=True)
#     code_csv = os.path.join(result_path, 'java_clean_code.csv')
#
#     all_records = []
#
#     for release in releases:
#         record = extract_tokens_from(release)
#         all_records.extend(record)
#
#     if all_records:
#         df = pd.DataFrame(all_records, columns=['file', 'content', 'label'])
#         df.to_csv(code_csv, index=False, encoding='utf-8')
#
