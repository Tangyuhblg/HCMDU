import os
import re
import csv
import math
import warnings
import pandas as pd


try:
    from radon.complexity import cc_visit
    from radon.metrics import h_visit
except Exception:
    cc_visit = None
    h_visit = None

# 可用于 Java AST（更准确），若没装则自动回退到启发式
try:
    import javalang
    HAVE_JAVALANG = True
except Exception:
    HAVE_JAVALANG = False

warnings.filterwarnings("ignore", category=UserWarning)


# -------------------- 行统计 --------------------
LINE_COMMENT = re.compile(r'//.*?$', re.MULTILINE)
BLOCK_COMMENT = re.compile(r'/\*.*?\*/', re.DOTALL)
STRING_CHAR = re.compile(r'(\"[^\"\\]*(?:\\.[^\"\\]*)*\")|(\'.*?\')', re.DOTALL)

def strip_comments_java(code: str) -> str:
    """兜底去注释（CSV 多半已去注释，这里确保万无一失）"""
    code = re.sub(BLOCK_COMMENT, '', code)
    code = re.sub(LINE_COMMENT, '', code)
    return code

def split_line_stats(code: str):
    """lOCode, lOComment(=0), lOBlank, lOCodeAndComment"""
    lines = code.splitlines()
    l_blank = sum(1 for ln in lines if ln.strip() == "")
    l_code = len(lines) - l_blank
    return l_code, 0, l_blank, l_code

# -------------------- Halstead（Java） --------------------
# 运算符与界符集合（用于 Halstead 的操作符）
JAVA_OPS = {
    # 多字符优先考虑
    ">>>=", "<<=", ">>=", "==", "!=", ">=", "<=", "&&", "||", "+=", "-=", "*=", "/=", "%=",
    "&=", "|=", "^=", "->", "::", "<<", ">>",
    # 单字符
    "+","-","*","/","%","~","&","|","^","=","!",">","<","?",":",".",",",";","(",")","{","}","[","]",
    # 关键词当作操作符（用于 Halstead 统计）
    "if","else","for","while","do","switch","case","default",
    "break","continue","return",
    "try","catch","finally","throw","throws",
    "new","instanceof","synchronized","assert",
    "yield","record","sealed","permits"
}

NUMBER_PATTERN = re.compile(
    r'\b(?:0[xX][0-9a-fA-F_]+|0[bB][01_]+|0[0-7_]+|[0-9][0-9_]*'
    r'(?:\.[0-9_]+)?(?:[eE][+\-]?[0-9_]+)?)\b'
)
IDENT_PATTERN = re.compile(r'\b[A-Za-z_][A-Za-z0-9_]*\b')

def tokenize_java(code: str):
    """轻量 tokenizer：保留符号；把字符串/字符字面量替换为空格，避免内部符号干扰"""
    code_ = re.sub(STRING_CHAR, ' ', code)

    # 用占位避免长操作符被拆碎
    multi_ops = [
        ">>>=", "<<=", ">>=", "==", "!=", ">=", "<=", "&&", "||",
        "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "->", "::",
        "<<", ">>"
    ]
    placeholders = {}
    for i, op in enumerate(sorted(multi_ops, key=len, reverse=True)):
        ph = f"__OP{i}__"
        placeholders[ph] = op
        code_ = code_.replace(op, f" {ph} ")

    for ch in list("+-*/%~&|^=!?:.,;(){}[]"):
        code_ = code_.replace(ch, f" {ch} ")

    for ph, op in placeholders.items():
        code_ = code_.replace(ph, f" {op} ")

    tokens = [t for t in code_.split() if t.strip()]
    return tokens

def halstead_from_tokens(tokens):
    """依据 tokens 计算 Halstead 指标"""
    n1_set, n2_set = set(), set()
    N1, N2 = 0, 0

    for t in tokens:
        if t in JAVA_OPS:
            n1_set.add(t); N1 += 1
        elif NUMBER_PATTERN.fullmatch(t):
            n2_set.add("__NUM__"); N2 += 1
        elif IDENT_PATTERN.fullmatch(t):
            if t in JAVA_OPS:  # 安全判断
                n1_set.add(t); N1 += 1
            else:
                n2_set.add(t); N2 += 1
        else:
            # 兜底：未知的符号倾向当操作数
            n2_set.add(t); N2 += 1

    n1, n2 = len(n1_set), len(n2_set)
    n = n1 + n2
    N = N1 + N2

    V = N * math.log2(n) if n > 0 and N > 0 else 0.0
    D = ((n1 / 2.0) * (N2 / n2)) if n2 > 0 else 0.0
    I = (V / D) if D > 0 else 0.0
    E = D * V
    B = V / 3000.0
    T = E / 18.0

    return {
        "uniq_Op": n1, "uniq_Opnd": n2,
        "total_Op": N1, "total_Opnd": N2,
        "n": n, "l": N, "v": V, "d": D, "i": I, "e": E, "b": B, "t": T
    }

# -------------------- 圈复杂度 v(G) & branchCount --------------------
# 启发式决策点：if/for/while/do/?:/&&/||/case/catch
DECISION_RE = re.compile(r'\bif\b|\bfor\b|\bwhile\b|\bcase\b|\bcatch\b|\?|\&\&|\|\||\bdo\b', re.MULTILINE)

def decisions_heuristic(code_no_str: str) -> int:
    return len(re.findall(DECISION_RE, code_no_str))

def complexity_ev_iv(code_no_str: str, vG: int):
    """
    近似计算：
    - ev(G): 1 + (break + continue + max(0, return-1)) capped by vG
    - iv(G): 1 + (含调用的分支/循环行数) capped by vG
    """
    breaks = len(re.findall(r'\bbreak\b', code_no_str))
    conts = len(re.findall(r'\bcontinue\b', code_no_str))
    rets = len(re.findall(r'\breturn\b', code_no_str))
    ev = 1 + breaks + conts + max(0, rets - 1)
    ev = min(ev, vG)

    integration_points = 0
    call_re = re.compile(r'\b[A-Za-z_][A-Za-z0-9_]*\s*\(')
    for ln in code_no_str.splitlines():
        if re.search(r'\b(if|for|while|switch|catch)\b', ln) and call_re.search(ln):
            integration_points += 1
    iv = 1 + integration_points
    iv = min(iv, vG)
    return ev, iv

# 使用 javalang 提高 v(G)（更接近真实 CFG 的决策点计数）
def vG_with_javalang(code: str) -> int:
    try:
        tree = javalang.parse.parse(code)
    except Exception:
        return None

    decisions = 0

    # 遍历 AST 统计决策节点
    for path, node in tree:
        n = type(node).__name__
        if n in {"IfStatement", "WhileStatement", "DoStatement",
                 "ForStatement", "EnhancedForControl", "SwitchStatement", "CatchClause"}:
            decisions += 1
        # switch: 每个 case 也算决策
        if n == "SwitchStatement":
            try:
                cases = node.cases or []
                decisions += max(0, len(cases) - 1)  # 通常 case 数 - 1
            except Exception:
                pass
        # 条件表达式 ?:
        if n == "ConditionalExpression":
            decisions += 1

    # 逻辑与或
    # 直接扫描源码，避免遗漏
    code_ns = re.sub(STRING_CHAR, ' ', code)
    decisions += len(re.findall(r'&&|\|\|', code_ns))

    # Cyclomatic complexity = decisions + 1
    return 1 + decisions

# -------------------- 主流程：读取 CSV，计算度量 --------------------
def analyze_from_java_csv(input_csv, output_csv):

    df = pd.read_csv(input_csv)

    # 兼容不同列名
    need = {"file", "content", "label"}
    if not need.issubset(set(df.columns)):
        raise ValueError(f"CSV 缺少必要列 {need}，实际列：{list(df.columns)}")

    os.makedirs(os.path.dirname(output_csv), exist_ok=True)

    with open(output_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "file", "loc", "v(G)", "ev(G)", "iv(G)",
            "n", "v", "l", "d", "i", "e", "b", "t",
            "lOCode", "lOComment", "lOBlank", "lOCodeAndComment",
            "uniq_Op", "uniq_Opnd", "total_Op", "total_Opnd",
            "branchCount", "defects"
        ])

        for _, row in df.iterrows():
            file_path = str(row.get("file", ""))
            # module = str(row.get("release", "")) if "release" in df.columns else ""
            code_raw = str(row.get("content", "") or "")
            defects = int(row.get("label", 0))

            # 行统计（LOC 等）
            code = strip_comments_java(code_raw)
            lOCode, lOComment, lOBlank, lOCodeAndComment = split_line_stats(code)
            loc = lOCode

            # Halstead
            tokens = tokenize_java(code)
            hs = halstead_from_tokens(tokens)

            # v(G) & branchCount
            if HAVE_JAVALANG:
                vG = vG_with_javalang(code)
            else:
                vG = None
            if vG is None:
                decisions = decisions_heuristic(code)
                vG = 1 + decisions
                branchCount = decisions
            else:
                # 分支数与 v(G)-1 对应
                branchCount = max(0, vG - 1)

            # ev(G), iv(G)
            evG, ivG = complexity_ev_iv(code, vG)

            writer.writerow([
                file_path, loc, vG, evG, ivG,
                hs["n"], hs["v"], hs["l"], hs["d"], hs["i"], hs["e"], hs["b"], hs["t"],
                lOCode, lOComment, lOBlank, lOCodeAndComment,
                hs["uniq_Op"], hs["uniq_Opnd"], hs["total_Op"], hs["total_Opnd"],
                branchCount, defects
            ])

    print(f"源代码向量已保存到: {output_csv}")


# if __name__ == "__main__":

    # input_path = './Result/java_clean_code.csv'
    # output_path = './Result/code_vectors.csv'
    #
    # analyze_from_java_csv(input_path, output_path)
