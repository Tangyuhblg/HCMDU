# -*- coding: utf-8 -*-
"""
@Time ： 2021/11/17 15:04
@Auth ： zhensu1998
@File ：SDUS1.py
@IDE ：PyCharm
@Mail：2286583124@qq.com

"""

from collections import Counter
import logging
from Comparison import SDUS_SPN
import numpy as np
import warnings
warnings.filterwarnings('ignore')
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s : %(message)s')
import random
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import KFold
import matplotlib.pyplot as plt
import time
from sklearn.preprocessing import MinMaxScaler
import math
import struct
from Comparison import Evaluation_indexs
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
import warnings
warnings.filterwarnings('ignore')

# 0:the minority class
# 1:the majority class
class SDUS1:
    def __init__(self):
        self.X = None
        self.y = None
        self.Sinfor = None  # SPN information
        self.S_maj = []   # Indicates an SPN that needs to be independently selected
        self.S_rest = []   # Indicates an SPN that needs to be aggregated for selection
        self.maj_num = None
        self.min_num = None
        self.ID = []    # Sample index of majority to be selected

    def distance(self, ma, mb):
        l = len(ma)
        abt = np.matrix(ma) * np.matrix(mb.T)
        sqa = np.tile(np.sum(ma ** 2, axis=1), l).reshape((l, l)).T
        sqb = np.tile(np.sum(mb ** 2, axis=1), l).reshape((l, l))
        dis_matrix = np.sqrt(sqa + sqb - 2 * abt + 0.0001)
        return np.array(dis_matrix)

    def weight_norm(self, matrix):
        sum_ = np.sum(matrix)
        # 如果 sum_ 为零，返回一个均匀分布，避免除以零
        if sum_ == 0 or np.isnan(sum_):
            return np.ones(len(matrix)) / len(matrix)
        matrix = list([x / sum_ for x in matrix])
        return matrix

    def weighted_under_sampling(self, id, weight, num):
        select_index = np.random.choice(id, size=num, p=weight)
        return select_index

    def fit(self, X, y):
        self.X = X
        self.y = y
        dic = Counter(self.y)
        spn = SDUS_SPN.SDUS_SPN()
        self.Sinfor = spn.fit(self.X, self.y)
        self.maj_num, self.min_num = dic[1], dic[0]

        # Determine how many of each SPN should be sampled, if greater than or equal to 1,
        # then sample independently, otherwise aggregate and sample
        for S in self.Sinfor:
            if (len(S['id']) / self.maj_num) * self.min_num >= 1:
                self.S_maj.append(S)
            else:
                self.S_rest.append(S)

        # Whether there is an SPN with the number of samples to be sampled greater than or equal to 1 within the SPN
        if len(self.S_maj) != 0:
            select_num = 0
            for S in self.S_maj:
                id_num = len(S['id'])
                sel_num = round(id_num / self.maj_num * self.min_num)
                select_num = select_num + sel_num

                sample_set = self.X[S['id']]
                dis_matrix = self.distance(sample_set, sample_set)
                sum_matrix = np.sum(dis_matrix, axis=1)
                norm_matrix = self.weight_norm(sum_matrix)
                weights = norm_matrix
                sampled = self.weighted_under_sampling(S['id'], weights, sel_num)
                for temp_sampled_index in sampled:
                    self.ID.append(temp_sampled_index)

            # If the number of selected classes is less than the number of minority classes then continue to select from the aggregated SPNs
            if select_num < self.min_num:
                if len(self.S_rest) != 0:
                    sample_set_rest_index = []
                    for S in self.S_rest:
                        for index in S['id']:
                            sample_set_rest_index.append(index)

                    sample_set_rest = self.X[sample_set_rest_index]
                    select_num_rest = round(len(sample_set_rest) / self.maj_num * self.min_num)
                    dis_matrix_rest = self.distance(sample_set_rest, sample_set_rest)
                    sum_matrix_rest = np.sum(dis_matrix_rest, axis=1)
                    sum_matrix_rest = 1 / sum_matrix_rest
                    sum_matrix_rest = self.weight_norm(sum_matrix_rest)

                    weights = sum_matrix_rest
                    sampled = self.weighted_under_sampling(sample_set_rest_index, weights, select_num_rest)
                    for temp_sampled_index in sampled:
                        self.ID.append(temp_sampled_index)

            re_maj = np.c_[self.X[np.array(self.ID)], np.ones(len(self.ID))]
            re_min = np.c_[self.X[np.where(self.y == 0)[0]], np.zeros(self.min_num)]
            resample = np.r_[re_maj, re_min]
            return resample

        else:  # if none of the SPNs need to sample more than 1 sample
            sample_set_index = []
            for S in self.S_rest:
                for index in S['id']:
                    sample_set_index.append(index)
            sample_set = self.X[sample_set_index]
            select_num = self.min_num
            dis_matrix = self.distance(sample_set, sample_set)
            sum_matrix = np.sum(dis_matrix, axis=1)
            sum_matrix = 1 / sum_matrix
            sum_matrix = self.weight_norm(sum_matrix)
            weights = sum_matrix
            sampled = self.weighted_under_sampling(sample_set_index, weights, select_num)
            for temp_sampled_index in sampled:
                self.ID.append(temp_sampled_index)

            re_maj = np.c_[self.X[np.array(self.ID)], np.ones(len(self.ID))]
            re_min = np.c_[self.X[np.where(self.y == 0)[0]], np.zeros(self.min_num)]
            resample = np.r_[re_maj, re_min]

            return resample

if __name__ == '__main__':

    start_time = time.time()

    data_frame = np.array(pd.read_csv(r'../data/brackets.csv'))
    print('样本个数: ', data_frame.shape[0], '特征个数: ', data_frame.shape[1] - 1)
    data = data_frame[:, : -1]
    target = data_frame[:, -1]
    print('缺陷率：', np.sum(target == 1) / data.shape[0])

    # 归一化
    scaler = MinMaxScaler()
    data = scaler.fit_transform(data)

    n_split = 5
    kfold = KFold(n_splits=n_split, shuffle=True, random_state=42)

    CART_F_measure, CART_TPR, CART_FPR, CART_FNR, CART_G_mean, CART_MCC, CART_AUC = [], [], [], [], [], [], []
    F_measure, TPR, FPR, FNR, G_mean, MCC, AUC = [], [], [], [], [], [], []
    F_measure_smo, FPR_smo, FNR_smo, G_mean_smo, MCC_smo, AUC_smo = [], [], [], [], [], []
    for kf, (train_index, test_index) in enumerate(kfold.split(data)):
        X_train, X_test = data[train_index], data[test_index]
        y_train, y_test = target[train_index], target[test_index]
        # print('多数类数量%d, 少数类数量%d' % (len(X_train[y_train == 0]), len(X_train[y_train == 1])))

        # SDUS1
        sdus1 = SDUS1()
        data_sdus1 = sdus1.fit(X_train, y_train)
        X_train_sdus = data_sdus1[:, :-1]
        y_train_resample = data_sdus1[:, -1]
        # 标签互换
        y_train_resample0 = y_train_resample[y_train_resample == 0]
        y_train_resample1 = y_train_resample[y_train_resample == 1]
        y_train_resample0 = np.ones(len(y_train_resample0))
        y_train_resample1 = np.zeros(len(y_train_resample1))
        y_train_sdus = np.concatenate((y_train_resample0, y_train_resample1), axis=0)

        model = RandomForestClassifier(random_state=42)
        model.fit(X_train_sdus, y_train_sdus)
        pred = model.predict(X_test)
        fmeasure, tpr, fpr, fnr, gmean, mcc, auc = Evaluation_indexs.evaluation_indexs(y_test, pred)
        TPR.append(tpr)
        FPR.append(fpr)
        FNR.append(fnr)
        G_mean.append(gmean)
        MCC.append(mcc)
        AUC.append(auc)
        print('*' * 50)

        cart = DecisionTreeClassifier(random_state=42)
        cart.fit(X_train_sdus, y_train_sdus)
        pred = cart.predict(X_test)
        fmeasure, tpr, fpr, fnr, gmean, mcc, auc = EI.evaluation_indexs(y_test, pred)
        CART_TPR.append(tpr)
        CART_FPR.append(fpr)
        CART_FNR.append(fnr)
        CART_F_measure.append(fmeasure)
        CART_G_mean.append(gmean)
        CART_MCC.append(mcc)
        CART_AUC.append(auc)

    print(G_mean, MCC, AUC, FPR, FNR)
    print('*' * 25, 'RF', '*' * 25)
    print('SDUS G-mean: %.4f' % np.mean(G_mean))
    print('SDUS MCC: %.4f' % np.mean(MCC))
    print('SDUS AUC: %.4f' % np.mean(AUC))
    print('SDUS FPR: %.4f' % np.mean(FPR))
    print('SDUS FNR: %.4f' % np.mean(FNR))

    print('*' * 50)
    print(CART_G_mean, CART_MCC, CART_AUC, CART_FPR, CART_FNR)
    print('SDUS G-mean: %.4f' % np.mean(CART_G_mean))
    print('SDUS MCC: %.4f' % np.mean(CART_MCC))
    print('SDUS AUC: %.4f' % np.mean(CART_AUC))
    print('SDUS FPR: %.4f' % np.mean(CART_FPR))
    print('SDUS FNR: %.4f' % np.mean(CART_FNR))

    end_time = time.time()
    print('总时间%ds' % (end_time - start_time))

