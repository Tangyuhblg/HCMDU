import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import KFold
from sklearn.preprocessing import MinMaxScaler
import warnings
warnings.filterwarnings('ignore')
from Comparison import Evaluation_indexs
from source_code.extract_csv import extract_tokens_from
from source_code.extract_vectors import analyze_from_java_csv
from HCMDU import Hamming_hilbert
import os
import warnings
warnings.filterwarnings('ignore')
import time


if __name__ == '__main__':

    # ------------------------1 源代码文件预处理------------------
    '''  
        (1) 提取源代码文件路径
        (2) 删除源代码中的注释
        (3) 提取源代码标签
    '''
    dataset_string = './source_code/Dataset'
    result_string = 'Result'

    file_level_path = f'{dataset_string}/File-level/'
    result_path = f'{result_string}'

    file_level_path_suffix = '_ground-truth-files_dataset.csv'

    releases = ['amq-5.0.0', 'ambari-1.2.0']

    for dataset in releases:
        print('*' * 30 + f'开始处理数据集：{dataset}' + '*' * 30)
        print('-' * 30 + '1 源代码文件预处理正在进行中' + '-' * 30)
        # 删除源代码中的注释，只保留源代码
        os.makedirs(result_path, exist_ok=True)
        code_csv = os.path.join(result_path, f'{dataset}-java_clean_code.csv')

        all_records = [] # 保存文件名，源代码和标签

        for release in releases:
            record = extract_tokens_from(file_level_path, release, file_level_path_suffix)
            all_records.extend(record)

        if all_records:
            df = pd.DataFrame(all_records, columns=['file', 'content', 'label'])
            df.to_csv(code_csv, index=False, encoding='utf-8')
            print(f'源代码预处理结果已保存到：{code_csv}')

        # -----------------------2 从源代码中提取向量------------------
        print('-' * 30 + '2 源代码中提取向量正在进行中' + '-' * 30)
        input_path = f'Result/{dataset}-java_clean_code.csv'
        output_path = f'Result/{dataset}-code_vectors.csv'

        analyze_from_java_csv(input_path, output_path)

        # -----------------------3 使用模型学习向量特征------------------
        print('-' * 30 + '3 使用模型学习向量特征正在进行中' + '-' * 30)
        df = pd.read_csv(f'Result/{dataset}-code_vectors.csv')
        print("是否有缺失值:", df.isnull().values.any())

        data_frame = np.array(pd.read_csv(f'Result/{dataset}-code_vectors.csv'))
        print('样本个数: ', data_frame.shape[0], '特征个数: ', data_frame.shape[1] - 2)
        data = data_frame[:, 1: -1]
        target = data_frame[:, -1].astype(int)
        print('缺陷率：', np.sum(target == 1) / data.shape[0])

        features_name = list(df.columns[1:-1])

        # 归一化
        scaler = MinMaxScaler()
        data = scaler.fit_transform(data)

        n_split = 5
        kfold = KFold(n_splits=n_split, shuffle=True, random_state=42)

        origin_index = df.index.to_numpy() # 原始行号
        # 预先分配一个数组来存放“整体验证集预测标签”，便于回填到原始表
        # 初始化为 -1 表示训练集或尚未预测
        y_pred_all = np.full(shape=(len(df),), fill_value=-1, dtype=int)
        # 收集所有预测为缺陷=1 的“原始行号”
        predicted_defect_rows = []

        # -----------------------4 使用HCMDU平衡数据级再进行预测---------------------------------
        print('-' * 30 + '4 HCMDU平衡数据集正在进行中' + '-' * 30)

        F_measure, TPR, FPR, FNR, G_mean, MCC, AUC = [], [], [], [], [], [], []
        F_measure_smo, FPR_smo, FNR_smo, G_mean_smo, MCC_smo, AUC_smo = [], [], [], [], [], []
        for kf, (train_index, test_index) in enumerate(kfold.split(data)):
            X_train, X_test = data[train_index], data[test_index]
            y_train, y_test = target[train_index], target[test_index]

            X_train_ham, y_train_ham = Hamming_hilbert(X_train, y_train) # HCMDU

            # 保存平衡后的数据集
            combine_path = f'Result/{dataset}-imbalanced_data{kf}.csv'
            n_feature = X_train.shape[1]
            out_df = pd.DataFrame(X_train, columns=features_name)
            out_df['label'] = y_train.astype(int)
            out_df.to_csv(combine_path, index=False, encoding='utf-8')
            print(f'训练集保存到：{combine_path}')


            model = RandomForestClassifier(random_state=42)
            model.fit(X_train_ham, y_train_ham)
            pred = model.predict(X_test)

            # 把本折预测映射回“原始数据行号”
            global_test_rows = origin_index[test_index]  # 本折验证集对应的原始行号
            defect_mask = (pred == 1)
            defect_rows_this_fold = global_test_rows[defect_mask]
            predicted_defect_rows.extend(defect_rows_this_fold.tolist())
            # 同时把本折预测标签写入 y_pred_all（对应原始行号）
            y_pred_all[global_test_rows] = pred

            tpr, fpr, fnr, gmean, mcc, auc = Evaluation_indexs.evaluation_indexs(y_test, pred)
            TPR.append(tpr)
            FPR.append(fpr)
            FNR.append(fnr)
            G_mean.append(gmean)
            MCC.append(mcc)
            AUC.append(auc)

        print(G_mean, AUC, FPR, FNR)
        print('输出HCMDU评价指标：')
        print('希尔伯特 G-mean: %.4f' % np.mean(G_mean))
        print('希尔伯特 MCC: %.4f' % np.mean(MCC))
        print('希尔伯特 AUC: %.4f' % np.mean(AUC))
        print('希尔伯特 FPR: %.4f' % np.mean(FPR))
        print('希尔伯特 FNR: %.4f' % np.mean(FNR))

        # 直接给出“预测为缺陷=1”的原始行号列表
        # print("预测为缺陷的原始行号总数：", len(predicted_defect_rows))
        predicted_defect_rows_1based = [i+1 for i in predicted_defect_rows]
        # print("前20个原始行号:", predicted_defect_rows_1based[:20])

        # 把预测结果回填到原始表并导出映射 CSV
        df_out = df.copy()
        df_out['predict_defect'] = y_pred_all  # -1=训练集/未预测，0=预测不缺陷，1=预测缺陷
        # 只导出验证集中出现过的行（y_pred_all!=-1），并按“预测为1”筛选
        pred_defect_df = df_out[df_out['predict_defect'] == 1].copy()
        pred_defect_df.insert(0, 'origin_index', pred_defect_df.index + 1) # 原始数据从0开始
        pred_defect_df.insert(1, 'predict_index', pred_defect_df.index + 1)

        # 保存映射文件（包含原始行号 + 原始字段 + 预测标签）
        out_map_path = f'Result/{dataset}-predicted_defects.csv'
        pred_defect_df.to_csv(out_map_path, index=False, encoding='utf-8')
        # print(f"预测为缺陷的样本已保存到: {out_map_path}")

        # 保存最终文件
        java_code = pd.read_csv(f'Result/{dataset}-java_clean_code.csv')
        java_file_content = java_code['content']
        file_content= java_file_content.iloc[pred_defect_df.index]
        predict_csv = pred_defect_df.join(file_content)
        # 保留origin and predict的index and label, source code
        col = ['file', 'content', 'origin_index', 'predict_index', 'defects', 'predict_defect']
        output_path = f'Result/{dataset}-predict_defect_code.csv'
        predict_csv[col].to_csv(output_path, index=False, encoding='utf-8')
        print(f'缺陷预测结果已保存到：{output_path}')

